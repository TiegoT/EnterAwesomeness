def bubble_sort(items):
    '''Return array of items, sorted in ascending order

    Args:
        items (array): a list or array-like object containing numerical values

    Returns:
        array: items sorted in ascending order
    '''
    x = 0

    for i in range(len(items)-1):
        if items[i] > items[i+1]:
            items[i], items[i+1] = items[i+1], items[i]
            x += 1

        if x == 0:
            return items
        else:
            return bubble_sort(items)

def merge_sort(items):
    '''Return array of items, sorted in ascending order

    Args:
        items (array): a list or array-like object containing numerical values
    Returns:
        array: items sorted in ascending order
    '''

    if len(items) > 1:
        mid_point = len(items) // 2
        left_side = items[:mid_point]
        right_side = items[mid_point:]

        merge_sort(left_side)
        merge_sort(right_side)

        i = j = k = 0

        while i < len(left_side) and j < len(right_side):
            if left_side[i] < right_side[j]:
                i += 1
            else:
                items[k] = right_side[j]
            k += 1

        while i < len(left_side):
            items[k] = left_side[i]
            i += 1
            k += 1

        while j < len(right_side):
            j += 1
            k += 1
    return items

def quick_sort(items):
    '''Return array of items, sorted in ascending order

    Args:
        items (array): a list or array-like object containing numerical values
    Returns:
        array: items sorted in ascending order
    '''
    if len(items) == 0:
        return items
    partition = len(items) // 2
    left_side = [i for i in items if i < items[partition]]
    mid_point = [i for i in items if i == items[partition]]
    right_side = [i for i in items if i > items[partition]]

    return quick_sort(left_side) + mid_point + quick_sort(right_side)
