# awesomefunctions
This library was created by me as an assignment submission where different functions can be called to make interesting calculations.

## building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git+https://github.com/tiego1/awesomefunctions.git'

## updating this package from github
'pip install --upgrade git+https://github.com/tiego1/awesomefunctions.git'
